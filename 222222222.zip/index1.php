<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cloud Computing Hardware | Premium PC Components</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-900 text-white font-sans">

    <nav class="bg-gray-800 border-b border-blue-500 p-4 sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-2xl font-bold text-blue-400">CLOUD COMPUTING <span class="text-white">HARDWARE</span></h1>
            <div class="space-x-6 hidden md:flex">
                <a href="#" class="hover:text-blue-400 transition">Components</a>
                <a href="#" class="hover:text-blue-400 transition">Pre-built PCs</a>
                <a href="#" class="hover:text-blue-400 transition">Laptops</a>
                <a href="#" class="hover:text-blue-400 transition text-red-500 font-bold">Hot Deals</a>
            </div>
            <div class="flex space-x-4 items-center">
                <i class="fas fa-search cursor-pointer"></i>
                <i class="fas fa-shopping-cart cursor-pointer text-blue-400"></i>
            </div>
        </div>
    </nav>

    <header class="relative h-64 bg-gradient-to-r from-blue-900 to-gray-900 flex items-center justify-center">
        <div class="text-center">
            <h2 class="text-4xl font-extrabold mb-2 uppercase tracking-widest">Upgrade Your Setup</h2>
            <p class="text-blue-300">The best hardware in Morocco, hosted on Azure.</p>
        </div>
    </header>

    <main class="container mx-auto py-12 px-4">
        <div class="flex justify-between items-center mb-8">
            <h3 class="text-2xl font-bold border-l-4 border-blue-500 pl-4 uppercase">New Arrivals</h3>
            <span class="text-sm text-gray-400">Showing 4 items</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php
            // Array to simulate a database of hardware
            $products = [
                ["name" => "RTX 4080 Super", "price" => "14,500 DH", "img" => "https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&q=80&w=400"],
                ["name" => "Ryzen 9 7950X", "price" => "7,200 DH", "img" => "https://images.unsplash.com/photo-1591405351990-4726e331f141?auto=format&fit=crop&q=80&w=400"],
                ["name" => "32GB DDR5 RAM", "price" => "1,800 DH", "img" => "https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&q=80&w=400"],
                ["name" => "2TB NVMe SSD", "price" => "1,450 DH", "img" => "https://images.unsplash.com/photo-1544650039-228809403328?auto=format&fit=crop&q=80&w=400"]
            ];

            foreach ($products as $p) : ?>
                <div class="bg-gray-800 rounded-lg overflow-hidden border border-gray-700 hover:border-blue-500 transition-all duration-300 group">
                    <div class="relative overflow-hidden">
                        <img src="<?= $p['img'] ?>" alt="<?= $p['name'] ?>" class="w-full h-48 object-cover group-hover:scale-110 transition duration-500">
                        <div class="absolute top-2 right-2 bg-blue-600 text-xs px-2 py-1 rounded">In Stock</div>
                    </div>
                    <div class="p-5">
                        <h4 class="text-lg font-semibold mb-2"><?= $p['name'] ?></h4>
                        <p class="text-2xl font-bold text-blue-400 mb-4"><?= $p['price'] ?></p>
                        <button class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded transition">
                            <i class="fas fa-cart-plus mr-2"></i> Add to Cart
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer class="bg-gray-950 text-gray-500 py-8 text-center border-t border-gray-800">
        <p>&copy; <?= date("Y") ?> Cloud Computing Hardware - Azure Web App Production</p>
    </footer>

</body>
</html>